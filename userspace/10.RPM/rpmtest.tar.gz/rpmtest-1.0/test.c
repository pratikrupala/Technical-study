#include <stdio.h>

int main(void)
{
	printf("Hello from test program.\n");

	return 0;
}
